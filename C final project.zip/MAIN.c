#include<conio.h>
#include<stdio.h>
#include<string.h>
#include<windows.h>
#include <time.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <process.h>
#define maxchar 1000


void chooselogin(void);
void login(void);
int predictiong(void);
void predictionmc();


typedef struct
{
    int rank;
    float cm;
    char ctg[10],g,username[40];
}details;

details s;


typedef struct
{
    char clgname[50],place[50],course[100];
    float opc,clc;
    int noseats;

}record;

record row[maxchar];

/*typedef struct
{
    char cclgname[50],cplace[50],ccourse[100];
    float copc,cclc;
    int noseats,book;
}neww;

neww flash[maxchar];
neww flashread[maxchar];*/

int book=0;


struct web
{
	char name[30],pass[30];
}w[99];

int calculatecutoff()
{
    int phy,chem,maths;
    float cutoff;
    printf("\n\n\t\t\t\tEnter your Physics mark:");
    scanf("%d",&phy);
    printf("\n\n\t\t\t\tEnter your Chemistry mark:");
    scanf("%d",&chem);
    printf("\n\n\t\t\t\tEnter your Mathematics mark:");
    scanf("%d",&maths);
    cutoff= (phy/2.0) + (chem/2.0) + maths;
    return cutoff;
}

void writedetails(details s)
{
    int a;
    FILE *fd;
    fd=fopen("details.txt","a+");
    printf("\t\t\t\t\tTNEA college predictor\n");
    printf("enter your name");
    scanf("%s",s.username);
    printf("%s",s.username);
    printf("Gender\n");
    printf("Male M   Female F  Other");
    fflush(stdin);
    scanf(" %c",&s.g);
    printf("\n");
    printf("12th cut-off\n");
    s.cm=calculatecutoff();

    /*if(a!=s.cm)
    {
        printf("\n\n\n\t\tenter correct cutoff marks");
        goto l2;
    }*/
    printf("Your TNEA rank\n");
    scanf("%d",&s.rank);
    printf("Category\n");
    scanf("%s",s.ctg);
    fd=fopen("details.txt","a");
    if(fd==NULL)
    {
        printf("error\n");
    }
    fprintf(fd,"%s %0.2f %c %d %s\n",s.username,s.cm,s.g,s.rank,s.ctg);
    /*fprintf(fd,"%s",s.username);*/
    fclose(fd);
    system("cls");
    chooselogin();

}

/*void editprofile()
{
    system("cls");
    FILE *fd;
    printf("\n");
    char name[50],tname[50],tg,tctg[5],nname[30],nctg[5];
    int trank,flag=0,r;
    float tcm;
    printf("enter your username\n");
    scanf("%s",name);
    printf("\n\n");
    fd=fopen("details.txt","a+");
    if(fd==NULL)
    {
        printf("file doesnt exist\n");
        exit(0);
    }
    while(fscanf(fd,"%s %f %c %d %s",tname,&tcm,&tg,&trank,tctg)!=EOF)
    {
        if(strcmp(tname,name)==0)
        {
            printf("\t\t\tEDITING\n");
            printf("Name\n");
            scanf(" %s",nname);
            printf("%s",nname);
            printf("Category\n");
            scanf(" %s",nctg);
            printf("%s",nctg);
            fprintf(fd,"%s %f %c %d %s",nname,&tcm,&tg,&trank,nctg);
            break;


        }
    }
    fclose(fd);

}*/

void profile()
{

    system("cls");
    FILE *fd;
    fd=fopen("details.txt","r");
    if(fd==NULL)
    {
        printf("file doesnt exist\n");
        exit(0);
    }
    char name[50],tname[50],tg,tctg[5];
    int trank,flag=0,r;
    float tcm;
    printf("enter username\n");
    scanf("%s",name);
    printf("\n\n");
    while(fscanf(fd,"%s %f %c %d %s",tname,&tcm,&tg,&trank,tctg)!=EOF)
    {
        if(strcmp(tname,name)==0)
        {
            printf("USERNAME :  %s\nGENDER : %c\nCUT-OFF MARK : %0.2f\nTNEA RANK : %d\nCATEGORY %s\n",tname,tg,tcm,trank,tctg);
            flag++;
        }
    }
    if(flag==0)
    {
        printf("no details of user : %s\n",name);
    }
    printf("\n\n\n");
    /*printf("Do You wish to edit your profile\n 1.YES\t\t2.NO");
    scanf("%d",&r);
    switch(r)
    {
        case 1:
            ("cls");
            editprofile();
        case 2:
            ("cls");
            chooselogin();

    }*/
    chooselogin();

}



int predictiong()
{

    char toread[maxchar];
    int rowcount=0,input,i=0;
    FILE *fp;
    float a;
    fp=fopen("list_of_clg.csv","r");
    /*printf("enter your cutoff\n");
    scanf("%d",&input);*/
    if(fp==NULL)
    {
        printf("error\n");
    }
    while(fgets(toread,maxchar,fp)!=NULL)
    {
        int fieldcount=0;
        rowcount++;
        if(rowcount==1)
        {
            continue;
        }
        char *sp;
        sp=strtok(toread,",");
        while(sp)
        {
            if(fieldcount==0)
            {
                strcpy(row[i].clgname,sp);
                /*printf("%s\n",row[i].clgname);*/
            }
            if(fieldcount==1)
            {
                strcpy(row[i].place,sp);
                /*printf("%s\n",row[i].place);*/
            }
            if(fieldcount==2)
            {
                strcpy(row[i].course,sp);
                /*printf("%s\n",row[i].course);*/
            }
            if(fieldcount==3)
            {
                row[i].opc=atof(sp);
                /*printf("%0.2f\n",row[i].opc);*/
            }
            if(fieldcount==4)
            {
                row[i].clc=atof(sp);
                /*printf("%0.2f\n",row[i].clc);*/
            }
            if(fieldcount==5)
            {
                row[i].noseats=atoi(sp);
                /*printf("%0.2f\n",row[i].clc);*/
            }
            sp=strtok(NULL,",");
            fieldcount++;
        }
        i++;

    }
    return i;
    fclose(fp);
    //printf("%d\n",book);

}

void filterb(char *branch,int a,int input)
{
    for(int i=0;i<a;i++)
    {

        if((strcmp(row[i].course,branch)==0 ) && (input>=row[i].opc && input<=row[i].clc))
            {
                printf("%-45s %-20s %-50s  %0.2f %0.2f\t%d\n",row[i].clgname,row[i].place,row[i].course,row[i].opc,row[i].clc,row[i].noseats);
            }
    }
    printf("\n\n\n\t\t\t");
    char clg[50],toread[maxchar],cour[50];
    FILE *fp;
    fp=fopen("list_of_list.csv","r+");
    if(fp==NULL)
    {
        printf("error\n");
    }
    FILE *f1;
    f1=fopen("report.txt","a+");
    if(f1==NULL)
    {
        printf("error\n");
    }
    printf("\t\t\tCHOOSE THE COLLEGE YOU PREFER\n");
    scanf("%*c%[^\n]s",clg);
    //printf("\t\t\tCHOOSE THE COURSE YOU PREFER\n");
    //scanf("%*c%[^\n]s",cour);
    printf("\n\n\n\n\n");
    for(int i=0;i<a;i++)
    {

        if((strcmp(row[i].course,branch)==0 ) && (input>=row[i].opc && input<=row[i].clc))
        {
                if(strcmp(clg,row[i].clgname)==0)
                {
                    book=row[i].noseats-(row[i].noseats-1);
                    fprintf(f1,"%s %s %s %0.2f %0.2f %d \n",row[i].clgname,row[i].place,row[i].course,row[i].opc,row[i].clc,book);
                    row[i].noseats=row[i].noseats-1;
                    //fseek(0,i,0);
                    //putw(row[i].noseats,fp);
                    while(fgets(toread,maxchar,fp)!=NULL)
                    {
                        //printf("hi\n");
                        int fieldcount=0;
                        char *sp;
                        sp=strtok(toread,",");
                        while(sp)
                        {
                            if(fieldcount==5)
                            {
                                //printf("inside\n");
                                fprintf(fp,"%d",atoi(row[i].noseats));
                            }
                            sp=strtok(NULL,",");
                            fieldcount++;
                        }
                    }
                }
        }
    }
    rewind(f1);
    char string[100];
    while(fgets(string,maxchar,f1)!=NULL)
    {
        //printf("hello inside fgets\n");
        printf("%s\n",string);
    }
    fclose(f1);
    /*FILE *p1;
    p1=fopen("clgname.txt","w");
    fprintf(p1,"%s %s",clg,cour);
    fclose(p1);*/
}

void filtera(char *area,int a,int input)
{
    int flag=-1;
    for(int i=0;i<a;i++)
    {

        if((strcmp(row[i].place,area)==0 ) && (input>=row[i].opc && input<=row[i].clc))
            {
                printf("%-45s %-20s %-50s  %0.2f  %0.2f\t%d\n",row[i].clgname,row[i].place,row[i].course,row[i].opc,row[i].clc,row[i].noseats);
            }
    }
    chooselogin();
}

filterba(char *branch,char *area,int a,int input)
{
    int flag=-1;
    for(int i=0;i<a;i++)
    {

        if((strcmp(row[i].course,branch)==0 ) && (strcmp(row[i].place,area)==0 ) && (input>=row[i].opc && input<=row[i].clc))
            {
                printf("%-45s %-20s %-50s  %0.2f  %0.2f\t%d\n",row[i].clgname,row[i].place,row[i].course,row[i].opc,row[i].clc,row[i].noseats);
            }
    }
    chooselogin();
}


void chooselogin()
{
    int n;
    ("cls");
    printf("\n\n\n\t\t\t1.View Profile\n");
    printf("\t\t\t2.Predict College\n");
    printf("\t\t\t3.Feedback\n");
    printf("\t\t\t4.Logout\n");
    scanf("%d",&n);
    switch(n)
    {
        case 1:("cls");
            profile();
            break;
        case 2:("cls");
            int a,input=0;
            printf("enter cutoff\n");
            scanf("%d",&input);
            a=predictiong();
            for(int i=0;i<a;i++)
            {
                if(input>=row[i].opc && input<=row[i].clc)
                {
                   printf("%-45s %-20s %-50s  %0.2f\t%0.2f\t\t%d\n",row[i].clgname,row[i].place,row[i].course,row[i].opc,row[i].clc,row[i].noseats);
                }
            }
            printf("\n\n\n\n\n");
            int r=0;
            char branch[50],area[50];
            printf("Filter According to\n \t\t\t1.branch\n \t\t\t2.place\n \t\t\t3.both");
            scanf("%d",&r);
            switch(r)
            {
                case 1:
                    printf("enter your preferred course\n");
                    scanf("%*c%[^\n]s",branch);
                    printf("\n");
                    filterb(branch,a,input);
                    break;
                case 2:
                    printf("enter the place");
                    scanf("%s",area);
                    printf("\n\n");
                    filtera(area,a,input);
                    break;
                default:
                    printf("enter your preferred course\n");
                    scanf("%*c%[^\n]s",branch);
                    printf("\n");
                    printf("enter the place");
                    scanf("%s",area);
                    printf("\n\n");
                    filterba(branch,area,a,input);
            }
            break;
        case 3:("cls");
            break;
        case 4: ("cls");
            printf("Successfully Logged Out\n");
            break;

    }
}

void choosereg()
{
    int n;
    ("cls");
    printf("\n\n\n\t\t\t1.Create Profile\n");
    printf("\t\t\t2.Predict College\n");
    printf("\t\t\t3.Feedback\n");
    printf("\t\t\t4.Logout\n");
    scanf("%d",&n);
    switch(n)
    {
        case 1:("cls");
            writedetails(s);
            break;
        case 2:("cls");
            int a,input=0;
            printf("enter cutoff\n");
            scanf("%d",&input);
            a=predictiong();
            for(int i=0;i<a;i++)
            {
                if(input>=row[i].opc && input<=row[i].clc)
                {
                    printf("%-45s %-20s %-50s  %0.2f\t%0.2f\t%d\n",row[i].clgname,row[i].place,row[i].course,row[i].opc,row[i].clc,row[i].noseats);
                }
            }
            printf("\n\n\n\n\n");
            int r=0;
            char branch[50],area[50];
            printf("Filter According to\n \t\t\t1.branch\n \t\t\t2.place\n \t\t\t3.both");
            scanf("%d",&r);
            switch(r)
            {
                case 1:
                    printf("enter your preferred course\n");
                    scanf("%*c%[^\n]s",branch);
                    filterb(branch,a,input);
                    break;
                case 2:
                    printf("enter the place");
                    scanf("%s",area);
                    filtera(area,a,input);
                    break;
                default:
                    printf("enter your preferred course\n");
                    scanf("%*c%[^\n]s",branch);
                    printf("enter the place");
                    scanf("%s",area);
                    filterba(branch,area,a,input);
            }
            break;
        case 3:("cls");
            break;
        case 4: ("cls");
            break;

    }
}



/*registration*/
void reg()
{
    int n;
    FILE *f1;
    char c,checker[30]; int z=0;
    f1=fopen("userdetails.txt","a+");
    /*printf("%ld\n", ftell(f1));*/
    fseek(f1,0,SEEK_END);  /*  moving the pointer to the end */
   /* printf("%ld", ftell(f1));*/
    printf("\n\n\t\t\t\tWELCOME TO REGISTER ZONE");
    printf("\n\t\t\t\t^^^^^^^^^^^^^^^^^^^^^^^^");
    for(int i=0;i<100;i++)
    {
      printf("\n\n\t\t\t\t  ENTER USERNAME: ");
      scanf("%s",checker);
      rewind(f1);
        while(!feof(f1))
        {
          //fread(&w[i],sizeof(w[i]),1,f1);
          fscanf(f1,"%s %s",w[i].name,w[i].pass);
          if(strcmp(checker,w[i].name)==0)
          {
            printf("\n\n\t\t\tUSERNAME ALREADY EXISTS");
            ("cls");
            reg();
          }
          else
          {
            strcpy(w[i].name,checker);
            break;
          }
        }
      printf("\n\n\t\t\t\t  DESIRED PASSWORD: ");
      while((c=getch())!=13)
        {
          w[i].pass[z++]=c;
          printf("%c",'*');
        }
        fseek(f1,0,2);
      //fwrite(&w[i],sizeof(w[i]),1,f1);
      fprintf(f1,"%s %s \n",w[i].name,w[i].pass);
      //rewind(f1);
      fclose(f1);
      printf("\n\n\tPress enter if you agree with Username and Password");
      if((c=getch())==13)
        {
        ("cls");
        printf("\n\n\t\tYou are successfully registered");
        printf("\n\n\t\tTry login your account??\n\n\t\t  ");
        printf("> PRESS 1 FOR YES\n\n\t\t  > PRESS 2 FOR NO\n\n\t\t\t\t");
        scanf("%d",&n);
        switch(n)
          {
              case 1: ("cls");
                    login();
                    break;
              case 2: ("cls");
                    printf("\n\n\n\t\t\t\t\tTHANK YOU FOR REGISTERING");
                    choosereg();
                    break;
          }
        }
        break;
      }
    getch();
}


  /*user login*/
void login()
{
      FILE *f1;
      char c;int z=0;
      int i=0;
      char name[30],pass[30];
      int checku,checkp;
      f1=fopen("userdetails.txt","r");
      printf("\n\n\t\t\t\tWELCOME TO LOG IN ZONE");
      printf("\n\t\t\t\t^^^^^^^^^^^^^^^^^^^^^^");
      for(i=0;i<1000;i++)
      {
        printf("\n\n\t\t\t\t  ENTER USERNAME: ");
        scanf("%s",name);
        printf("\n\n\t\t\t\t  ENTER PASSWORD: ");
        while((c=getch())!=13)
        {
          pass[z++]=c;
          printf("%c",'*');
        }
        pass[z]='\0';
      while(!feof(f1))
        {
          //fread(w,sizeof(struct web),1,f1);
          l1:fscanf(f1,"%s %s",w[i].name,w[i].pass);
          //printf("%s",w[i].name);
          checku=strcmp(name,w[i].name);
          checkp=strcmp(pass,w[i].pass);
          if(feof(f1))
          {

            printf("\n\n\n\t\t\tWrong username or password");
            login();
          }
          if(checku==0&&checkp==0)
          {
            //("cls");
            printf("\n\n\n\t\t\tYOU HAVE LOGGED IN SUCCESSFULLY!!");
            printf("\n\n\n\t\t\t\tWELCOME, HAVE A NICE DAY");
            break;
          }
        else if(checku!=0||checkp!=0)
          {
            //printf("\n\n\n\t\t\tWRONG PASSWORD!! Not %s??",name);
            //printf("\n\n\t\t\t\t  (Press 'Y' to re-login)");
            //if(getch()=='y'||getch()=='Y')
                goto l1;
              //login();
          }
        /*else if(checku!=0)
          {
            printf("\n\n\n\t\t\tYou are not a Registered User\n \t\t\tPress enter to register yourself");
            if(getch()==13)
            ("cls");
            reg();
          }*/
        }
        break;
      }
      getch();
      chooselogin();
      //rewind(f1);
      fclose(f1);

}





void user()
{
    int n;
    L1:
    printf("\n\n\n\t\t\t1. LOGIN\t\t2. REGISTER");
    printf("\n\n\n\t\t\t\tENTER YOUR CHOICE: ");
    scanf("%d",&n);
    switch(n)
    {
        case 1: ("cls");
            login();
            break;
        case 2: ("cls");
            reg();
            break;
        default:
            printf("\n\n\t\t\t\tNO MATCH FOUND");
            printf("\n\n\t\t\tPress Enter to re-Enter the choice");
            if(getch()==13)
            ("cls");
            goto L1;
    }


}



int main()
{
    int nas;
    ("cls");
    printf("\n\n\n\n\n\t\t\t\tWELCOME TO MY WEBSITE");
    printf("\n\t\t\t\t=====================");
    printf("\n\n\n\n\t\t\tPress Enter to proceed...!!");
    if(getch()==13)
    ("cls");
    user();



}
